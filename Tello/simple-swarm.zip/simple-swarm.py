from djitellopy import TelloSwarm
from djitellopy import Tello

import cv2, math, time


swarm = TelloSwarm.fromIps([
    "192.168.137.91",
    "192.168.137.11"
])
swarm1 = TelloSwarm.fromIps([
    "192.168.137.91"
])
swarm2 = TelloSwarm.fromIps([
    "192.168.137.11"
])
swarm.connect()
swarm.query_battery()
swarm.takeoff()

# run in parallel on all tellos
# 同时在所有Tello上执行
swarm.move_up(50)
swarm1.rotate_clockwise(90)
swarm2.rotate_counter_clockwise(90)
swarm.curve_xyz_speed(70, 70, 0, 100, 0, 0, 20)
swarm.rotate_counter_clockwise(90)
swarm1.go_xyz_speed(0,50,-50,20)
swarm2.go_xyz_speed(0,50,50,20)
# swarm2.rotate_clockwise(180)
swarm1.go_xyz_speed(-50,0,50,20)
swarm2.go_xyz_speed(-50,0,-50,20)
swarm.flip_left()
swarm.go_xyz_speed(50,50,0,20)
swarm2.rotate_clockwise(180)
swarm.flip_back()
# run by one tello after the other
# 让Tello一个接一个执行
# swarm.sequential(lambda i, tello: tello.move_forward(20))

# making each tello do something unique in parallel
# 让每一架Tello单独执行不同的操作
# swarm1.move_up(50)

# swarm2.move_down(50)

# swarm1.move_up(50)

# swarm2.move_down(50)

# swarm2.move_down(50)

# swarm1.move_right(50)

# swarm2.move_left(50)

# swarm1.move_forward(50)

# swarm2.move_back(50)

# swarm1.move_down(50)

# swarm2.move_up(50)

# swarm2.flip_left(50)

# swarm2.flip_right(50)

# swarm1.move_right(50)

# swarm2.move_left(50)

# swarm1.move_back(50)

# swarm2.move_forward(50)

key = cv2.waitKey(1) & 0xff
if key == ord('o'):
    swarm.emergency()

# swarm.sequential(lambda i, tello: tello.move_back(20))

swarm.land()
swarm.end()
